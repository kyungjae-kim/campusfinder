CREATE DATABASE  IF NOT EXISTS `studydb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `studydb`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: studydb
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `messages`
--

DROP TABLE IF EXISTS `messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `messages` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `content` text NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `handover_id` bigint NOT NULL,
  `is_blinded` bit(1) NOT NULL,
  `is_read` bit(1) NOT NULL,
  `is_reported` bit(1) NOT NULL,
  `read_at` datetime(6) DEFAULT NULL,
  `sender_id` bigint NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `messages`
--

LOCK TABLES `messages` WRITE;
/*!40000 ALTER TABLE `messages` DISABLE KEYS */;
INSERT INTO `messages` VALUES (1,'안녕하세요','2025-12-29 05:15:52.949909',1,_binary '\0',_binary '',_binary '\0','2025-12-29 05:15:55.216960',4),(2,'안녕하세요','2025-12-29 05:15:59.051368',1,_binary '\0',_binary '',_binary '\0','2025-12-29 05:16:03.464240',3),(3,'제거인거같아요','2025-12-29 05:16:12.543565',1,_binary '\0',_binary '',_binary '\0','2025-12-29 05:16:13.300996',3),(4,'네','2025-12-29 05:16:16.533925',1,_binary '\0',_binary '',_binary '\0','2025-12-29 05:16:18.507294',4),(5,'ㅁㄷㅈㄱㅈㅁㄷㄱㅈㅁㄷㄱㄷㅈㅁㄱ1ㅁㅈ56ㄷ4ㄱㅈㅁㄷㄱ','2025-12-29 05:16:20.993971',1,_binary '\0',_binary '',_binary '\0','2025-12-29 05:16:23.176332',4),(6,'aewfwafe','2025-12-30 00:42:31.993441',1,_binary '\0',_binary '\0',_binary '\0',NULL,3),(7,'패딩 맞나요..?','2025-12-30 07:24:44.692706',5,_binary '\0',_binary '',_binary '\0','2025-12-30 07:25:06.797368',3),(8,'맞는거 같네요','2025-12-30 07:25:16.940712',5,_binary '\0',_binary '',_binary '\0','2025-12-30 07:25:21.843802',4),(9,'찾으러갈게요','2025-12-30 07:25:31.806305',5,_binary '\0',_binary '',_binary '\0','2025-12-30 07:25:36.753080',3),(10,'학생회관','2025-12-30 07:27:37.966836',5,_binary '\0',_binary '',_binary '\0','2025-12-30 07:27:41.287746',4),(11,'에서 만나시죠','2025-12-30 07:27:41.499673',5,_binary '\0',_binary '',_binary '\0','2025-12-30 07:27:46.318189',4),(12,'네','2025-12-30 07:27:50.415758',5,_binary '\0',_binary '',_binary '\0','2025-12-30 07:27:54.071204',3);
/*!40000 ALTER TABLE `messages` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-31 17:14:01
