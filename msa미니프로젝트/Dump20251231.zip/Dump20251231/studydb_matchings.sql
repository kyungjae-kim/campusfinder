CREATE DATABASE  IF NOT EXISTS `studydb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `studydb`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: studydb
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `matchings`
--

DROP TABLE IF EXISTS `matchings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `matchings` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `created_at` datetime(6) DEFAULT NULL,
  `found_id` bigint NOT NULL,
  `lost_id` bigint NOT NULL,
  `reason` varchar(500) DEFAULT NULL,
  `score` int NOT NULL,
  `viewed` bit(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `matchings`
--

LOCK TABLES `matchings` WRITE;
/*!40000 ALTER TABLE `matchings` DISABLE KEYS */;
INSERT INTO `matchings` VALUES (1,'2025-12-29 05:11:52.918468',1,1,'카테고리 일치, 장소 근접, 날짜 근접(0일 차이), 키워드 1개 일치',75,_binary '\0'),(2,'2025-12-29 05:11:52.957782',2,1,'날짜 근접(0일 차이)',15,_binary '\0'),(3,'2025-12-29 06:39:42.413926',2,2,'카테고리 일치, 장소 근접, 날짜 근접(4일 차이), 키워드 2개 일치',85,_binary '\0'),(4,'2025-12-30 00:15:56.716979',3,3,'카테고리 일치, 장소 근접, 날짜 근접(0일 차이)',65,_binary '\0'),(5,'2025-12-30 00:30:47.980067',4,4,'카테고리 일치, 날짜 근접(0일 차이)',45,_binary '\0'),(6,'2025-12-30 00:30:47.979860',4,4,'카테고리 일치, 날짜 근접(0일 차이)',45,_binary '\0'),(7,'2025-12-30 07:24:22.398126',5,5,'카테고리 일치, 날짜 근접(0일 차이), 키워드 1개 일치',55,_binary '\0'),(8,'2025-12-30 08:05:18.542562',6,7,'카테고리 일치, 장소 근접, 날짜 근접(0일 차이), 키워드 1개 일치',75,_binary '\0'),(9,'2025-12-31 02:58:21.563060',6,8,'날짜 근접(0일 차이)',15,_binary '\0'),(10,'2025-12-31 02:58:21.599147',7,8,'카테고리 일치, 장소 근접, 날짜 근접(0일 차이), 키워드 1개 일치',75,_binary '\0'),(11,'2025-12-31 03:27:55.715449',8,8,'카테고리 일치, 날짜 근접(0일 차이), 키워드 2개 일치',65,_binary '\0'),(12,'2025-12-31 06:35:21.076913',7,7,'날짜 근접(0일 차이)',15,_binary '\0');
/*!40000 ALTER TABLE `matchings` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-31 17:14:01
