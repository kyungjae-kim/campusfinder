CREATE DATABASE  IF NOT EXISTS `studydb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `studydb`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: studydb
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `found_items`
--

DROP TABLE IF EXISTS `found_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `found_items` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `category` enum('ACCESSORY','BAG','BOOK','CLOTHING','ELECTRONICS','ETC','ID_CARD','SPORTS','STATIONERY','WALLET') NOT NULL,
  `created_at` datetime(6) DEFAULT NULL,
  `description` text,
  `found_at` datetime(6) NOT NULL,
  `found_place` varchar(200) NOT NULL,
  `owner_user_id` bigint NOT NULL,
  `status` enum('DISCARDED','HANDED_OVER','IN_HANDOVER','REGISTERED','STORED') NOT NULL,
  `storage_location` varchar(200) DEFAULT NULL,
  `storage_type` enum('LOCKER','OFFICE','SECURITY','SELF') NOT NULL,
  `title` varchar(200) NOT NULL,
  `updated_at` datetime(6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `found_items`
--

LOCK TABLES `found_items` WRITE;
/*!40000 ALTER TABLE `found_items` DISABLE KEYS */;
INSERT INTO `found_items` VALUES (1,'ELECTRONICS','2025-12-24 06:32:14.995945','에어팟 습득','2025-12-24 15:31:00.000000','공학관 2층',4,'HANDED_OVER','내 가방','SELF','에어팟','2025-12-29 05:48:26.183429'),(2,'WALLET','2025-12-24 06:49:11.865390','루이비통 지갑','2025-12-24 15:48:00.000000','중앙도서관',4,'HANDED_OVER','보관함 A-12','OFFICE','루이비통 지갑','2025-12-29 06:47:28.821280'),(3,'STATIONERY','2025-12-30 00:15:27.679444','브랜드는 모르겠는데 까만색 볼펜입니다.','2025-12-30 09:20:00.000000','관리실 근처',4,'HANDED_OVER','','SELF','볼펜을 주웠습니다.','2025-12-30 00:19:07.442976'),(4,'ELECTRONICS','2025-12-30 00:30:41.193320','애플 맥 15인치인 것 같습니다.','2025-12-30 09:31:00.000000','학생회관',4,'HANDED_OVER','','LOCKER','노트북을 습득했습니다.','2025-12-30 00:37:37.466505'),(5,'CLOTHING','2025-12-30 07:24:07.610908','노스페이스','2025-12-30 16:27:00.000000','도서관',4,'HANDED_OVER','','SELF','까만 외투','2025-12-30 07:27:52.872738'),(6,'ACCESSORY','2025-12-30 08:04:50.304383','반지','2025-12-30 20:04:00.000000','기숙사 옆 공원',4,'STORED','','OFFICE','반지','2025-12-31 00:39:52.549102'),(7,'SPORTS','2025-12-31 02:57:55.841721','야구 용품','2025-12-31 11:57:00.000000','운동장',4,'REGISTERED','','OFFICE','야구 용품','2025-12-31 02:57:55.841744'),(8,'SPORTS','2025-12-31 03:27:37.112133','야구 글러브','2025-12-31 12:27:00.000000','학생이 관리실로 가져옴',5,'HANDED_OVER','','OFFICE','야구 글러브','2025-12-31 03:29:17.391383');
/*!40000 ALTER TABLE `found_items` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-31 17:14:01
