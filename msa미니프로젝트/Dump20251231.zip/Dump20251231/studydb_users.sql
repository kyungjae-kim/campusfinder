CREATE DATABASE  IF NOT EXISTS `studydb` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `studydb`;
-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: studydb
-- ------------------------------------------------------
-- Server version	8.4.7

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `affiliation` enum('EXTERNAL','STAFF','STUDENT') DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `email` varchar(100) DEFAULT NULL,
  `nickname` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `role` enum('ADMIN','COURIER','FINDER','LOSER','OFFICE','SECURITY') NOT NULL,
  `status` enum('ACTIVE','BLOCKED','INACTIVE') NOT NULL,
  `updated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UKr43af9ap4edm43mmtq01oddj6` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,NULL,'2025-12-18 02:01:35','abcd@abc.com','a','$2a$10$e.pSRuvA6Gy4iVsiX36whemzhA/yOr8JD1dStIbyRbM7i/9njPUje','010-0000-0000','ADMIN','ACTIVE','2025-12-18 02:01:35','a'),(2,'STUDENT','2025-12-18 02:10:20','hong@test.com','홍길동','$2a$10$KtVBC.Ov8ygcyehQA18VU.JQ2ghWcOvyXi699GsqGa9ZmXoA80Aim','010-1234-5678','LOSER','BLOCKED','2025-12-31 06:25:08','hong123'),(3,'STUDENT','2025-12-23 02:38:24','aaa@aaa.com','loser','$2a$10$cgEQmpqagbq/cx1JQbcUEe3fouwFcAwhZqvW/.rwrA1ujf/Km0gaO','010-1234-1234','LOSER','ACTIVE','2025-12-23 02:38:24','loser'),(4,'STAFF','2025-12-23 02:47:28','bbb@bbb.com','founder','$2a$10$3H/yJm3B/almvYDDb7kOQ.FcU7TyVajxt7sK5raGSJDm3mZcfuR3C','010-4848-7984','FINDER','ACTIVE','2025-12-23 02:47:28','founder'),(5,'STAFF','2025-12-23 02:49:12','ccc@ccc.com','office','$2a$10$j5dgPNhvoWhhXwxwnor4C.GiK1EXsZsL/aClBks9M7fAH9/8uVHcm','010-4484-9879','OFFICE','ACTIVE','2025-12-23 02:49:12','office'),(6,'STAFF','2025-12-23 02:49:52','ddd@ddd.com','security','$2a$10$xmMQonha/leQ8VroMCJxMeUyoeKmyXHIlU.i/Lw501.R1zEn99kXy','010-4235-5641','SECURITY','ACTIVE','2025-12-23 02:49:52','security'),(7,'EXTERNAL','2025-12-23 02:50:45','eee@eee.com','courier','$2a$10$ENj8CmgkyYEHw3K.XZjEDOyWfpIvJEEEvpElg2pUqUt.oAZQXNiK6','010-3154-9873','COURIER','ACTIVE','2025-12-23 02:50:45','courier');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-31 17:14:01
